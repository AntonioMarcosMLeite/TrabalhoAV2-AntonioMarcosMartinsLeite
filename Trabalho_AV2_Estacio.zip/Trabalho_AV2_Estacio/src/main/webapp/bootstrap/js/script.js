$(function(){
    var operacao = "A";
    var indice_selecionado = -1;
    var tbClientes = localStorage.getItem("tbClientes");
    
    tbClientes = JSON.parse(tbClientes);
    if (tbClientes == null)
        tbClientes = [];
    
    $("#formCadastro").on ("submit", function(){
        if (operacao == "A")
             
            adicionarElemento();
        else
            editarElemento();
        
    });  
    //Função que preenche os campos do formulário com dados do local storage quando escolhe editar. 
    $("#tbLista").on("click", "#btnEditar", function(){
        
        operacao = "E";
        indice_selecionado = parseInt($(this).attr("alt"));
        var cli = JSON.parse(tbClientes[indice_selecionado]);
        $("#nome").val(cli.nome);
        $("#cpf").val(cli.cpf);
        $("#estCivil").val(cli.estcivil);
        $("#sexo").val(cli.sexo);        
        $("#telefone").val(cli.telefone);
        $("#cep").val(cli.cep);
        $("#endereco").val(cli.endereco);
        $("#bairro").val(cli.bairro);
        $("#estado").val(cli.estado);
        $("#cidade").val(cli.cidade);
        $("#email").val(cli.email);
        $("#senha").val(cli.senha);
        $("#obs").val(cli.obs);
        if(cli.promo == "1"){
            $("#promo").attr("checked", true);
             $("#msgpromo").show();
        } else {
           
            $("#promo").attr("checked", false);
            $("#msgpromo").hide();
        }
        
        $("#cpf").focus();
        listar();
    });
    
    //Função que emite um alerta para o usuário, e verifica se
    // realmente deseja excluir o arquivo selecionado.
    $("#tbLista").on("click", "#btnExcluir", function() {
  
   var x;
    //recebemos o valor do botão pressionado ok ou cancelar em uma variavel
    var r=confirm("Deseja Realmente Excluir?");
    if (r==true){
        
        indice_selecionado = parseInt($(this).attr("alt"));
        excluir();
        listar();
        limpar();
              
  }
    
});
          
      //Função para adicionar os dados do formulário no local Storage.      
    function adicionarElemento(){
      
        var cliente = JSON.stringify({
            nome     :  $("#nome").val(),
            cpf      :  $("#cpf").val(),
            estcivil :  $("#estCivil").val(),
            sexo     :  $("#sexo").val(),
            telefone :  $("#telefone").val(),
            cep      :  $("#cep").val(),
            endereco :  $("#endereco").val(),
            bairro   :  $("#bairro").val(),
            estado   :  $("#estado").val(),
            cidade   :  $("#cidade").val(),
            email    :  $("#email").val(),
            senha    :  $("#senha").val(),            
            obs      :  $("#obs").val(),            
            promo    :  $("#promo").val()
            
        });
       
        tbClientes.push(cliente);
        localStorage.setItem("tbClientes", JSON.stringify(tbClientes));
        alert("Registro adicionado com sucesso");
        return true;
    }
    
    //Função que lista as informações na tabela abaixo do formulário para visualização do usuário.
    function listar() {
        $("#tbLista").html("");
        $("#tbLista").html(
                "<thead>" +
                "   <tr>" +
                "       <th>CPF</th>" +
                "       <th>Nome</th>" +
                "       <th>Editar / Excluir</th>" +
                "   </tr>" +
                "</thead>" +
                "<tbody>" +
                "</tbody>"
                );
        for (var i in tbClientes) {
            var cli = JSON.parse(tbClientes[i]);

            var novaLinha = $("<tr>");
            var cols = "";


            cols += "<td>" + cli.cpf + "</td>";
            cols += "<td>" + cli.nome + "</td>";
            cols += "<td>" +
                    " <img src='img/edit.png' alt='" +
                    i + "' id='btnEditar'/>" + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
                 
                    "<img src='img/delete.png' alt='" +
                    i + "' id='btnExcluir'/>" + "</td>";
            novaLinha.append(cols);
          
            $("#tbLista").append(novaLinha);
        }
    }    
     
    listar();
    
    
    //Função que armazena os arquivos alterados no local storage.
    function editarElemento(){
	tbClientes[indice_selecionado] = JSON.stringify({
		  nome     :  $("#nome").val(),
                  cpf      :  $("#cpf").val(),
                  estcivil :  $("#estCivil").val(),
                  sexo     :  $("#sexo").val(),
                  telefone :  $("#telefone").val(),
                  cep      :  $("#cep").val(),
                  endereco :  $("#endereco").val(),
                  bairro   :  $("#bairro").val(),
                  estado   :  $("#estado").val(),
                  cidade   :  $("#cidade").val(),
                  email    :  $("#email").val(),
                  senha    :  $("#senha").val(),
                  obs      :  $("#obs").val(),
                  promo    :  $("#promo").val()
			
		});//Altera o item selecionado na tabela
	localStorage.setItem("tbClientes", JSON.stringify(tbClientes));
	alert("Registro Alterado.");
	operacao = "A"; //Volta ao padrão
	return true;
}
//Função para excluir arquivos.
function excluir(){
    
	tbClientes.splice(indice_selecionado, 1);
	localStorage.setItem("tbClientes", JSON.stringify(tbClientes));
	//alert("Registro Excluído.");
}
//Função para limpar formulário.
function limpar(){
    
     $("#formCadastro").each (function(){
          
            this.reset();
            $("#promo").attr("checked", false);
            $("#msgpromo").hide();
            $("#cpf").focus();
        
        });
}


});

    
$(document).ready(function(){
    
    //Funçao para criação de máscaras dos campos.
    $('#cpf').mask('999.999.999-99');
    $('#telefone').mask('(99) 9999-9999');
    $('#cep').mask('99999-999');
    
    //Função para tornar as letras maiusculas e impedir números e caracteres especiais no campo nome.
    $("#nome").keyup(function(){
    $(this).val($(this).val().toUpperCase());
    var valor = $("#nome").val().replace(/[^a-zA-Z" "]+/g,'');
		$("#nome").val(valor);
  });
  
   //Função para tornar os outros campos maiusculas.  
    $("#endereco").keyup(function(){
         $(this).val($(this).val().toUpperCase());
  });
    $("bairro").keyup(function(){
        $(this).val($(this).val().toUpperCase());
  });
    $("#estado").keyup(function(){
        $(this).val($(this).val().toUpperCase());
  });
    $("#endereco").keyup(function(){
        $(this).val($(this).val().toUpperCase());
  });
    $("#cidade").keyup(function(){
        $(this).val($(this).val().toUpperCase());
  });
    $("#obs").keyup(function(){
        $(this).val($(this).val().toUpperCase());
  });
     
   //Chama a função para validação do CPF. 
    $('#cpf').validacpf();
    
    /*Criei essa função para tornar o campo estado civil obrigatório
     pois ao tentar colocar required no campo estado civil e sexo, eles ja apresentavam
     o valor "Escolher opção" no campo e passava no required e se atribuisse o valor vazio
     para o campo, minha função de validação dos campos em questão não era chamada, então
     assim que o campo nome é prenchido ele seta o focous no campo estado civil e não deixa
     avançar sem escolher uma opção, depois de preenchido seta o focus no campo sexo*/
    $('#nome').blur(function(){
        
        if($("#nome").val() != ""){
            
            setTimeout(function(){
                   $("#estCivil").focus(); 
                });
		
        }
        
    });    
    
    //Função de validação do campo estado civil, não avança sem escolher uma opção.
    $("#estCivil").blur(function(){
        
       if ($("#estCivil").val() == "--Escolher uma Opção--" ){
                alert("Selecione uma opção antes de prosseguir");
		$("#estCivil").focus();
                }else{
                    
                    setTimeout(function(){
                   $("#sexo").focus(); 
                });
                    
                }
		
          });   
          
    //Função de validação do campo sexo, não avança sem escolher uma opção.
    $("#sexo").blur(function(){
        
       if ($("#sexo").val() == "--Escolher Sexo--" ){
                alert("Selecione uma opção antes de prosseguir");
                setTimeout(function(){
                   $("#sexo").focus(); 
                });
		
                }
		
          });   
          
     //Função de validação do campo Observação, limita o tamanho da mensagem.   
    $("#obs").blur(function(){  
          
          var TextMsg =  $("#obs").val();
          if (TextMsg.length > 200)
            {
                alert("Limite Excedido - Máximo 200 caracteres!!!!");
                $("#obs").focus();
               
                    }
          
             });
             
     //Função de validação do campo senha, não permite senha abaixo de 7 caracteres, nem espaços.       
    $("#senha").blur(function(){
        
        var senha = $("#senha").val();
          
	if( senha == "" || senha.length < 7 || senha.indexOf(' ','0')!= -1){
            alert("Digite uma Senha Válida.");
            $("#senha").val("");
               setTimeout(function(){
               $("#senha").focus(); 
             });
			
          }
	

     });
     
    //Função que limpa o formulário quando clica no botão cancelar.
    $( "#btn_cancelar" ).click(function() {
     
      $("#formCadastro").each (function(){
          
            this.reset();
            $("#promo").attr("checked", false);
            $("#msgpromo").hide();
            window.location.reload();
            
        
        });
    });  
    
        
    //Função para destacar o campo da tabela quando passamos o mouse em cima da linha.
    $("#tbLista tbody tr").hover(function(){
        $(this).addClass('destaque');
    },
    function(){
        $(this).removeClass('destaque');
    }
    );

    //Função para verificar se o usuário deseja receber promoções, mostra e oculta a mensagem.
    $("#promo").click(function(){	
	       
    if($("#promo").prop("checked")){
	$("#promo").val(1);//esse valor é setado para verificar se deve trazer o 
                           // campo selecionado ou não na hora de editar o dado do local storage.  	
	 $("#msgpromo").show();
	}
	else{
         $("#promo").val(2);//esse valor é setado para verificar se deve trazer o 
                            // campo selecionado ou não na hora de editar o dado do local storage.
         $("#msgpromo").hide();
	}
	
    });   
    
    // Função para preenchimento dos campos de endereço, passando apenas o CEP. 
    $("#cep").blur(function(event){   
                
                    var texto = $("#cep").val();
                    
                    //Função Ajax que envia o valor passado no cep para o servlet para que faça a validação.
                    $.ajax({
                         type: 'GET',
                         url: 'ServletAjax',
                         data:{
                             cep : texto
                         },
                         beforeSend: function(){
                             
                            
                         },
                         success: function(textoResposta){
                            
                            //Aqui recebe a resposta do servlet.
                            $(textoResposta).find('texto').each(function (){
                            var erro = $(this).text();
                            alert(erro);
                            $("#cep").val(""); 
                            $("#endereco").val("");
                            $("#bairro").val("");
                            $("#estado").val("");
                            $("#cidade").val("");
                            $("#cep").focus();
                            /*Aqui criei essas funções para limpar os campos no caso de edição,
                             por exemplo temos apenas um cep valido, se digitar outro cep ao clicar
                             em editar, ele mostraria o aviso de erro de cep inválido, mas os dados 
                             continuariam nos campos preenchidos, por isso setei valores vazios para
                             os campos para o caso de edição.*/
                           });
                            
                            //aqui recebe a resposta do servlet e preenche os campos com a informação.
                            $(textoResposta).find('endereco').each(function (){
                            var endereco = $(this).text();
                            
                            $('#endereco').val(endereco);
                           });
                            $(textoResposta).find('bairro').each(function (){
                            var bairro = $(this).text();
                            
                            $('#bairro').val(bairro);
                           });
                            $(textoResposta).find('estado').each(function (){
                            var estado = $(this).text();
                            
                            $('#estado').val(estado);
                           });
                            $(textoResposta).find('cidade').each(function (){
                            var cidade = $(this).text();
                            
                            $('#cidade').val(cidade);
                           });
                         },
                         
                         error: function(request, status, error){
                             alert(request.responseText);
                         }
                    });
                });
               
});
   
   //Função para realizar a validação do cpf.
   jQuery.fn.validacpf = function(){
       
    this.change(function(){
        CPF = $(this).val();        
        if(!CPF){ 
            return false;}
        erro  = new String;
        cpfv  = CPF;
               
        if(cpfv.length == 14 || cpfv.length == 11){
            cpfv = cpfv.replace('.', '');
            cpfv = cpfv.replace('.', '');
            cpfv = cpfv.replace('-', '');
 
            var nonNumbers = /\D/;
   
            if(nonNumbers.test(cpfv)){
                erro = "A verificacao de CPF suporta apenas números!";
                
            }else{
                if (cpfv == "00000000000" ||
                    cpfv == "11111111111" ||
                    cpfv == "22222222222" ||
                    cpfv == "33333333333" ||
                    cpfv == "44444444444" ||
                    cpfv == "55555555555" ||
                    cpfv == "66666666666" ||
                    cpfv == "77777777777" ||
                    cpfv == "88888888888" ||
                    cpfv == "99999999999") {
                           
                    erro = "Número de CPF inválido!"
                    $("#cpf").val("");
                        setTimeout(function(){
                        $("#cpf").focus(); 
                   });
                    
                    
                }
                var a = [];
                var b = new Number;
                var c = 11;
 
                for(i=0; i<11; i++){
                    a[i] = cpfv.charAt(i);
                    if (i < 9) b += (a[i] * --c);
                }
                if((x = b % 11) < 2){
                    a[9] = 0
                }else{
                    a[9] = 11-x
                }
                b = 0;
                c = 11;
                for (y=0; y<10; y++) b += (a[y] * c--);
   
                if((x = b % 11) < 2){
                    a[10] = 0;
                }else{
                    a[10] = 11-x;
                }
                if((cpfv.charAt(9) != a[9]) || (cpfv.charAt(10) != a[10])){
                    erro = "Número de CPF inválido.";
                    $("#cpf").val("");
                        setTimeout(function(){
                        $("#cpf").focus(); 
                   });
                   
                }
            }
        }else{
            if(cpfv.length == 0){
                return false;
            }else{
                erro = "Número de CPF inválido.";
                $("#cpf").val("");
                      setTimeout(function(){
                      $("#cpf").focus(); 
                   }); 
            }
        }
        if (erro.length > 0){
            $(this).val('');
            alert(erro);
            
            return false;
        }
        return $(this);
    });
    
    
};