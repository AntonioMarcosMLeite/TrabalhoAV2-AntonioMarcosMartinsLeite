 $(document).ready(function(){
        $('#cpf').mask('999.999.999-99');
        $('#telefone').mask('(99) 9999-9999');
        $('#cep').mask('99999-999');
 });



$(document).ready(function() {
  $("#nome").keyup(function(){
    $(this).val($(this).val().toUpperCase());
    var valor = $("#nome").val().replace(/[^a-zA-Z" "]+/g,'');
		$("#nome").val(valor);
  });
  $("#endereco").keyup(function(){
    $(this).val($(this).val().toUpperCase());
  });
  $("bairro").keyup(function(){
    $(this).val($(this).val().toUpperCase());
  });
  $("#estado").keyup(function(){
    $(this).val($(this).val().toUpperCase());
  });
  $("#endereco").keyup(function(){
    $(this).val($(this).val().toUpperCase());
  });
  $("#cidade").keyup(function(){
    $(this).val($(this).val().toUpperCase());
  });
  $("#obs").keyup(function(){
    $(this).val($(this).val().toUpperCase());
  });
});

/*$(document).ready(function(){
    
    $('#formCadastro').each (function(){
  this.reset();
});

});*/

